export class Employee {
    id!:number;
    empname!:string;
    email!:string;
    mobno!:string;
    designation!:string;
    username!:string;
    password!:string;
}
