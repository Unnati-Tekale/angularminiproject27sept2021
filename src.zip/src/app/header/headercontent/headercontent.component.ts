import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headercontent',
  templateUrl: './headercontent.component.html',
  styleUrls: ['./headercontent.component.css']
})
export class HeadercontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
